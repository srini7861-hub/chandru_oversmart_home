# OverSmart Home Telegram Bot

This is a simple Node.js server that sends alerts from ESP32 to Telegram.

## Usage
1. Deploy to Render
2. Set Environment Variables:
   - `BOT_TOKEN` = your Telegram bot token
   - `CHAT_ID` = your chat ID

## Test
Open in browser:

```
https://<your-app-name>.onrender.com/send?msg=Hello
```

You should receive a Telegram alert.
