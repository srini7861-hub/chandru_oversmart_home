import express from "express";
import fetch from "node-fetch";

const app = express();
const PORT = process.env.PORT || 3000;

const BOT_TOKEN = process.env.BOT_TOKEN;
const CHAT_ID = process.env.CHAT_ID;

app.get("/send", async (req, res) => {
  const msg = req.query.msg || "Hello from OverSmart Home";

  if (!BOT_TOKEN || !CHAT_ID) {
    return res.status(500).send("Missing BOT_TOKEN or CHAT_ID in environment");
  }

  try {
    const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage?chat_id=${CHAT_ID}&text=${encodeURIComponent(
      msg
    )}`;

    const response = await fetch(url);
    const data = await response.json();

    if (!data.ok) {
      console.error("Telegram error:", data);
      return res.status(500).send("Failed to send message");
    }

    res.send(`✅ Message sent: ${msg}`);
  } catch (err) {
    console.error(err);
    res.status(500).send("Error sending message");
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
