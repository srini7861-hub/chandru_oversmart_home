# OverSmart Chandru Home - Telegram API

This is a simple Node.js backend to send Telegram alerts from an ESP32 project.

## How to Use

1. Deploy this repo on Render.
2. Add Environment Variables in Render:
   - `BOT_TOKEN` = your Telegram BotFather token
   - `CHAT_ID` = your Telegram user ID (from @userinfobot)
3. After deployment, test in browser:

```
https://<your-service-name>.onrender.com/send?msg=Hello
```

You should get "Hello" as a Telegram message.

## Notes
- Make sure you clicked **Start** in your bot chat in Telegram.
- ESP32 can call the same URL to send alerts (gas leak, rain, intruder, etc).
